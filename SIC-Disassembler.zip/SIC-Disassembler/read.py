import re

file_path = 'opcodes.txt'  # Replace with the actual path to your opcodes.txt file

try:
    with open(file_path, 'r') as file:
        for line in file:
            # Split each line using any whitespace character as the delimiter
            values = re.split(r'\s+', line.strip())

            # Check if there are enough values
            if len(values) >= 3:
                s1, s2, s3 = values[:3]  # Unpack the first three values
                print("s1:", s1)
                print("s2:", s2)
                print("s3:", s3)
            else:
                print(f"Not enough values in line: {line.strip()}")

except FileNotFoundError:
    print(f"File not found: {file_path}")
except Exception as e:
    print(f"An error occurred: {e}")
