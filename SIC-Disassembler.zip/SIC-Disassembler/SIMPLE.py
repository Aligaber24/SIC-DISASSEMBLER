import re
hrecords = ''
trecords = []
erecord = ''
codelen = 0
startaddress = 0
labels = 0
llist = ["label0"]
labelss = []
flag1 = 0
flag2 = 0
loc_counter = 00
with open('codes.txt', 'r') as file:  # r is for read
    instruction = []
    opcode = []
    formatt = []  # create a list
    for line in file:
        values = re.split(r'\s+', line.strip())

        # Check if there are enough values
        if len(values) >= 3:
            instructionn, opcodee, formattt = values[:3]  # Unpack the first three values

        else:
            print(f"Not enough values in line: {line.strip()}")
        instruction.append(instructionn)
        opcode.append(opcodee)
        formatt.append(formattt)

# for data in instruction_set:
# print(f"instruction: {data['instruction']}, opcode: {data['opcode']},formatt: {data['formatt']}")
# printing list to make sure it's working

with open('sample_input2.txt', 'r') as file:
    for line in file:
        lines = file.readlines()
        first_characters = [line[0] for line in lines]
        i = 0
        while (i < len(first_characters)):
            if (first_characters[i] == 'H'):
                hrecords = lines[i]
            elif (first_characters[i] == 'T'):
                trecords.append(lines[i])
            elif (first_characters[i] == 'E'):
                erecord = lines[i]
            i = i + 1
codelen = int(hrecords[-7:], 16)
hrecords = hrecords[:-7]
startaddress = hrecords[-6:]
hrecords = hrecords[:-6]
hrecords = hrecords[1:]

with open('symbol.txt', 'w') as file:
    i = 0
    while (i < len(trecords)):
        workingrecord = [char for char in trecords[i]]
        workingrecord = workingrecord[7:]
        hexlen = workingrecord[0] + workingrecord[1]
        hexlen = int(hexlen, 16)
        workingrecord = workingrecord[2:]
        i = i + 1
        c = 0
        while (c < hexlen):
            check = workingrecord[0] + workingrecord[1]
            workingrecord = workingrecord[2:]
            m = 0
            flag2 = 0
            tr = int(check, 16)
            while (m < len(opcode)):
                if opcode[m] == check and formatt[m] == '3' and len(workingrecord) >= 4 and tr % 2 == 0:
                    address = workingrecord[0] + workingrecord[1] + workingrecord[2] + workingrecord[3]
                    if address not in labelss:
                        labelss.append(address)
                        # file.write(address)
                        # file.write("\t")
                        # file.write("label" + str(labels))
                        # file.write("\t\n")
                        l = "label" + str(labels)
                        labels = labels + 1
                        llist.append(l)
                    workingrecord = workingrecord[4:]
                    c = c + 3
                    flag2 = 1
                    break
                elif (tr % 2 != 0):
                    w = hex(int(check, 16) - 1)[2:]
                    if (len(w) < 2):
                        w = '0' + w
                    w = w.upper()
                    if w == opcode[m] and formatt[m] == '3' and len(workingrecord) >= 4:
                        workingrecord = workingrecord[4:]
                        c = c + 3
                        flag2 = 1
                        break

                # elif(opcode[m]==check and formatt[m]=='3' and len(workingrecord)>=2 and tr%2!=0):
                # imm=workingrecord[0]+workingrecord[1]+workingrecord[2]+workingrecord[3]
                # labelss.append(imm)
                # llist.append()

                m = m + 1
            if (flag2 == 0):
                c = c + 1
    labelss.sort()
    count = 0
    llist = llist[1:]
    while (count < len(labelss)):
        file.write(labelss[count])
        file.write("\t")
        file.write(llist[count])
        file.write("\t\n")
        count = count + 1

with open('ali.txt', 'w') as file:  # writing the h record
    file.write("\t")
    file.write(hrecords + "START")
    file.write("\t")
    file.write(startaddress)
    i = 0
    file.write("\n")
    c = 30
    k = codelen
    while (i < len(trecords)):
        workingrecord = [char for char in trecords[i]]
        workingrecord = workingrecord[1:]
        add = ''.join(workingrecord[:6])
        workingrecord = workingrecord[6:]
        l = ''.join(workingrecord[:2])
        length = int(l, 16)
        workingrecord = workingrecord[2:]
        add = int(add, 16)
        if (i > 0 and (add) > finishrecordaddress):
            pr = str((add - finishrecordaddress))
            file.write("\tRESB\t" + pr + "\n")
        c = 0
        finishrecordaddress = length + add
        # if(loc_counter>add):

        while (c < length):
            q = 0
            flag1 = 0
            thisop = workingrecord[0] + workingrecord[1]
            tr = int(thisop, 16)
            while (q < len(opcode)):
                if (thisop == opcode[q] and formatt[q] == '3' and len(workingrecord) >= 4 and tr % 2 == 0):
                    workingrecord = workingrecord[2:]
                    tempadd = workingrecord[0] + workingrecord[1] + workingrecord[2] + workingrecord[3]
                    workingrecord = workingrecord[4:]
                    kk=int(tempadd,16)
                    jj=int(startaddress,16)
                    index = labelss.index(tempadd) # getting label index
                    if(tempadd[0]=='8' or tempadd[0]=='9'):
                        print(0)
                        file.write("\t")
                        file.write(instruction[q])
                        file.write("\t")
                        file.write(llist[index]+",x")
                        file.write("\n")
                    else:
                        file.write("\t")
                        file.write(instruction[q])
                        file.write("\t")
                        file.write(llist[index] )
                        file.write("\n")
                    c = c + 3
                    k = k - 3
                    flag1 = 1
                    break
                elif (tr % 2 != 0):
                    w = hex(int(thisop, 16) - 1)[2:]
                    if (len(w) < 2):
                        w = '0' + w
                    w = w.upper()
                    if w == opcode[q] and formatt[q] == '3' and len(workingrecord) >= 4:
                        workingrecord = workingrecord[2:]
                        tempadd = workingrecord[0] + workingrecord[1] + workingrecord[2] + workingrecord[3]
                        workingrecord = workingrecord[4:]
                        file.write("\t")
                        file.write(instruction[q])
                        file.write("\t")
                        file.write("#" + tempadd)
                        file.write("\n")
                        c = c + 3
                        k = k - 3
                        flag1 = 1
                        break
                elif (thisop == opcode[q] and formatt[q] == '1'):
                    print(thisop)
                    workingrecord = workingrecord[2:]
                    file.write("\t")
                    file.write(instruction[q])
                    file.write("\t")
                    file.write("-")
                    file.write("\n")
                    c = c + 1
                    k = k - 1
                    flag1 = 1
                    break
                q = q + 1
            if (flag1 == 0):
                file.write("\tBYTE\tx'" + workingrecord[0] + workingrecord[1] + "\n")
                c = c + 1
                workingrecord = workingrecord[2:]
                k = k - 1

        i = i + 1
    z = int(finishrecordaddress)
    t = int(codelen)
    r = int(startaddress, 16)
    final = t + r - z
    if (final > 0):
        final = str(final)
        file.write("\tRESB\t" + final)

with open("ali.txt", "r") as file:
    opc = []
    labell = []
    for line in file:
        values = re.split(r'\s+', line.strip())

        # Check if there are enough values
        if len(values) >= 2:
            opcc, labelll = values[:2]  # Unpack the first three values

        else:
            print(f"Not enough values in line: {line.strip()}")
        opc.append(opcc)
        labell.append(labelll)

with open("ali.txt","w") as file:
    finalflag=0
    finallist=[]
    q = 1
    loc_counter=int(startaddress,16)
    file.write("\t\t" + opc[0] + "\t" + labell[0] + "\n")
    for arc in labelss:
        if arc<startaddress:
            finallist.append(arc)
    while(q<len(opc)):
        if(opc[q]=='RESB'):
            zq = str(hex(loc_counter)[2:])
            zq = zq.upper()
            if (len(zq) == 1):
                zq = "000" + zq
            elif (len(zq) == 2):
                zq = "00" + zq
            elif(len(zq) == 3):
                zq = "0" + zq
            if zq in labelss:
                r2 = labelss.index(zq)
                file.write( llist[r2]+"\t" + opc[q] + "\t" + labell[q] + "\n")
                loc_counter=loc_counter+int(labell[q])

                labelss[r2] = "\t"
            else:

                file.write("\t\t" + opc[q] + "\t" + labell[q] + "\n")
                loc_counter = loc_counter + labell[q]
        elif  opc[q] == 'BYTE':
            zq = str(hex(loc_counter)[2:])
            zq = zq.upper()
            if (len(zq) == 1):
                zq = "000" + zq
            elif (len(zq) == 2):
                zq = "00" + zq
            elif (len(zq) == 3):
                zq = "0" + zq
            if zq in labelss:
                r2 = labelss.index(zq)
                file.write(llist[r2]+"\t" + opc[q] + "\t" + labell[q] + "\n")
                loc_counter = loc_counter + 1
                labelss[r2] = "\t"
            else:

                file.write("\t\t" + opc[q] + "\t" + labell[q] + "\n")
                loc_counter = loc_counter + 1
        elif opc[q] == 'RSUB':
            file.write("\t\t" + opc[q] + "\t" + "\n")
            loc_counter=loc_counter+3

        else:
            temporary=instruction.index(opc[q])

            if(formatt[temporary]=='3'):

                zq=str(hex(loc_counter)[2:])
                zq=zq.upper()
                print(zq)
                if (len(zq) == 1):
                    zq = "000" + zq
                elif (len(zq) == 2):
                    zq = "00" + zq
                elif (len(zq) == 3):
                    zq = "0" + zq
                else:
                    zq=zq
                if zq in labelss:
                    r2 = labelss.index(zq)
                    pp=labelss[r2]
                    if((labelss[r2][0])=='8' or (labelss[r2][0])=='9'):
                        file.write(llist[r2] + "\t" + opc[q] + "\t" + labell[q] + ",x\n")
                    else:
                        file.write(llist[r2] + "\t" + opc[q] + "\t" + labell[q] + "\n")
                    loc_counter = loc_counter +3
                    labelss[r2] = "\t"
                else:

                    file.write("\t\t" + opc[q] + "\t" + labell[q] + "\n")
                    loc_counter = loc_counter + 3

            else:
                zq = str(hex(loc_counter)[2:])
                zq = zq.upper()
                if(len(zq)==1):
                    zq="000"+zq
                elif(len(zq)==2):
                    zq="00"+zq
                elif (len(zq) == 3):
                    zq = "0" + zq
                if zq in labelss:
                    r2=labelss.index(zq)
                    file.write(llist[r2] + "\t" + opc[q] + "\t" + labell[q] + "\n")
                    loc_counter = loc_counter + 1
                    labelss[r2]="\t"
                else:
                    file.write("\t\t" + opc[q] + "\t" + labell[q] + "\n")
                    loc_counter = loc_counter + 1

        q=q+1

    file.write("\t\tEND\t"+startaddress)
