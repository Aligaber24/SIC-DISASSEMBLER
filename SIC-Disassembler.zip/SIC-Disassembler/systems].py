elif opc[q] == 'WORD':
if zq in labelss:
    r2 = labelss.index(zq)
    file.write(llist[r2] + "\t" + opc[q] + "\t" + labell[q] + "\n")
    loc_counter = loc_counter + 3
    labelss[r2] = "\t"
else:

    file.write("\t\t" + opc[q] + "\t" + labell[q] + "\n")
    loc_counter = loc_counter + 3





if(kk<jj):
                        file.write("\tWORD\t00"+tempadd+"\n")
                        c = c + 3
                        k = k - 3
                        flag1 = 1
                        break
                    else:
